package br.ufes.inf.lprm.sensoryeffect.renderer.message;

public interface SensoryEffectMessage {

}
